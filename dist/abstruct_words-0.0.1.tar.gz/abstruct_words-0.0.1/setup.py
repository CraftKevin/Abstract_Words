from distutils.core import setup

setup(
    name = 'abstruct_words',
    version = '0.0.1',
    py_modules = ['ab'],
    author = 'yanghaomai',
    author_email='yhm12345@foxmail.com',
    url = 'https://gitee.com/yanghaomai',
    description='a converter to change chiness into abstruct words'
    )
